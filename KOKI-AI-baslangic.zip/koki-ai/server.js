import http from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join, normalize } from "node:path";

const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-6-astra";
const ROOT = new URL("./public/", import.meta.url).pathname;

const server = http.createServer(async (req, res) => {
  const set = (type) => {
    res.setHeader("Content-Type", type);
    res.setHeader("X-Content-Type-Options", "nosniff");
  };

  if (req.method === "POST" && req.url === "/api/chat") {
    if (!API_KEY) {
      res.writeHead(500, { "Content-Type": "application/json; charset=utf-8" });
      return res.end(JSON.stringify({ error: "Sunucuda API anahtarı ayarlanmamış." }));
    }
    try {
      let raw = "";
      for await (const chunk of req) {
        raw += chunk;
        if (raw.length > 100_000) throw new Error("İstek çok büyük.");
      }
      const body = JSON.parse(raw || "{}");
      const messages = Array.isArray(body.messages) ? body.messages.slice(-20) : [];
      const input = messages
        .filter(m => ["user", "assistant"].includes(m.role) && typeof m.content === "string")
        .map(m => ({ role: m.role, content: m.content.slice(0, 6000) }));

      if (!input.length || input[input.length - 1].role !== "user") {
        res.writeHead(400, { "Content-Type": "application/json; charset=utf-8" });
        return res.end(JSON.stringify({ error: "Önce bir mesaj yaz." }));
      }

      const apiRes = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: MODEL,
          instructions: "Sen KOKI AI adlı yardımsever, güvenli ve açık konuşan bir Türkçe asistansın. Kullanıcı Türkçe yazarsa Türkçe cevap ver. Cevaplarını anlaşılır ve gereksiz uzatmadan ver. Bilmediğin şeyleri uydurma.",
          input
        })
      });

      const data = await apiRes.json();
      if (!apiRes.ok) {
        res.writeHead(apiRes.status, { "Content-Type": "application/json; charset=utf-8" });
        return res.end(JSON.stringify({ error: data?.error?.message || "Yapay zekâ servisine ulaşılamadı." }));
      }

      let answer = data.output_text;
      if (!answer && Array.isArray(data.output)) {
        answer = data.output.flatMap(item => item.content || [])
          .filter(part => part.type === "output_text")
          .map(part => part.text).join("\n");
      }
      res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
      return res.end(JSON.stringify({ answer: answer || "Şu anda cevap oluşturamadım." }));
    } catch (err) {
      res.writeHead(400, { "Content-Type": "application/json; charset=utf-8" });
      return res.end(JSON.stringify({ error: err.message || "Bir hata oluştu." }));
    }
  }

  if (req.method !== "GET" && req.method !== "HEAD") {
    res.writeHead(405); return res.end("Method Not Allowed");
  }
  const requested = req.url === "/" ? "/index.html" : decodeURIComponent((req.url || "/").split("?")[0]);
  const safe = normalize(requested).replace(/^(\.\.(\/|\\|$))+/, "").replace(/^[/\\]+/, "");
  try {
    const path = join(ROOT, safe);
    const content = await readFile(path);
    const types = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".png": "image/png", ".svg": "image/svg+xml" };
    set(types[extname(path)] || "application/octet-stream");
    res.writeHead(200);
    return res.end(req.method === "HEAD" ? undefined : content);
  } catch {
    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    return res.end("Sayfa bulunamadı.");
  }
});

server.listen(PORT, () => console.log(`KOKI AI çalışıyor: http://localhost:${PORT}`));
