KOKI AI - Başlangıç paketi

BU PAKET NE YAPIYOR?
- Telefon ve bilgisayar ekranına uyumlu sohbet arayüzü.
- Türkçe cevap veren KOKI asistanı.
- Sohbet sırasında önceki mesajları bağlam olarak gönderir.
- API anahtarı tarayıcıya gönderilmez; sunucuda tutulur.

ÖNEMLİ
Bu klasör tek başına internette yayınlanmış bir uygulama değildir. KOKI'nin cevap vermesi için Node.js çalışan bir sunucuya ve API anahtarına ihtiyaç vardır. API kullanımı ücretli olabilir; hesabındaki fiyat ve limitleri kontrol et.

KURULUM (bilgisayarda)
1. Node.js 18 veya daha yeni sürüm kur.
2. Bu klasörü aç.
3. .env.example dosyasını .env olarak kopyala.
4. .env dosyasındaki OPENAI_API_KEY alanına kendi API anahtarını yaz.
5. Terminalde bu klasörde:
   npm start
6. Tarayıcıdan http://localhost:3000 adresini aç.

İNTERNETE YAYINLAMA
Bu projeyi Node.js destekleyen bir sunucuya (ör. kendi VPS'in veya uygun bir uygulama barındırma servisi) yükle.
Sunucu ayarlarına OPENAI_API_KEY ve istersen OPENAI_MODEL değişkenlerini ekle.
API anahtarını HTML/JavaScript içine kesinlikle koyma ve kimseyle paylaşma.

TELEFONDA KULLANMA
Uygulama internete güvenli HTTPS adresiyle yayınlandıktan sonra Android Chrome'da aç.
Chrome menüsünden "Ana ekrana ekle" seçeneğini kullanabilirsin.

API
OpenAI Responses API kullanılır. Model adı OPENAI_MODEL ortam değişkeninden değiştirilebilir.
Resmî başlangıç: https://developers.openai.com/api/docs/quickstart
Güvenlik: https://developers.openai.com/api/reference/overview
