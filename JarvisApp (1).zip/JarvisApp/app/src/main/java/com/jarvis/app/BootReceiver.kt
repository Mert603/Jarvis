package com.jarvis.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Android 14+ mikrofon servisini arka planda boot'tan baslatmaya izin vermez.
        // Bu yuzden sadece uygulamayi acarsan servis baslar. Eski surumlerde denenir.
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Prefs.autoStart(context)) {
            try {
                context.startForegroundService(Intent(context, JarvisService::class.java))
            } catch (_: Exception) { }
        }
    }
}
