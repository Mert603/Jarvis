package com.jarvis.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ClaudeClient(private val apiKey: String) {

    // Hiz icin Haiku. Daha akilli cevap istersen "claude-sonnet-5-5" yap.
    private val model = "claude-haiku-5-5"

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val history = JSONArray()

    private val system = """
Sen Jarvis'sin, kullanicinin Android telefonundaki sesli asistan. Turkce konus.
Cevaplarin sesli okunacak: kisa (en fazla 2-3 cumle), duz metin, markdown, emoji ve liste kullanma.
Telefonda bir islem yapilmasi gerekiyorsa cevabinin SONUNA su etiketlerden birini ekle:
[OPEN:uygulama adi]  -> uygulama acar (ornek: [OPEN:YouTube])
[SEARCH:arama metni] -> internette arar
[ALARM:SS:DD]        -> alarm kurar, 24 saat formati (ornek: [ALARM:07:30])
[CALL:telefon no]    -> arama ekranini acar, sadece kullanici numara soylediyse
Etiketten once kullaniciya ne yaptigini kisaca soyle. Gerek yoksa etiket ekleme.
""".trimIndent()

    @Synchronized
    fun chat(userText: String): String {
        history.put(JSONObject().put("role", "user").put("content", userText))
        while (history.length() > 12) history.remove(0)
        // Konusma her zaman user ile baslamali
        while (history.length() > 0 && history.getJSONObject(0).getString("role") != "user") history.remove(0)

        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 300)
            .put("system", system)
            .put("messages", history)

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .header("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(req).execute().use { resp ->
            val raw = resp.body?.string() ?: ""
            if (!resp.isSuccessful) {
                history.remove(history.length() - 1)
                throw RuntimeException("API hatasi ${resp.code}: $raw")
            }
            val text = JSONObject(raw).getJSONArray("content").getJSONObject(0).getString("text")
            history.put(JSONObject().put("role", "assistant").put("content", text))
            return text
        }
    }
}
