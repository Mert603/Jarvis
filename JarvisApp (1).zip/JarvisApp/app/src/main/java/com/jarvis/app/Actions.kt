package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import java.net.URLEncoder

object Actions {
    private val tag = Regex("\\[(OPEN|SEARCH|ALARM|CALL):([^\\]]+)\\]")

    /** Etiketleri calistirir, etiketsiz konusma metnini dondurur. */
    fun run(context: Context, reply: String): String {
        tag.findAll(reply).forEach { m ->
            val arg = m.groupValues[2].trim()
            try {
                when (m.groupValues[1]) {
                    "OPEN" -> openApp(context, arg)
                    "SEARCH" -> start(context, Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(arg, "UTF-8"))))
                    "ALARM" -> {
                        val (h, min) = arg.split(":").map { it.trim().toInt() }
                        start(context, Intent(AlarmClock.ACTION_SET_ALARM)
                            .putExtra(AlarmClock.EXTRA_HOUR, h)
                            .putExtra(AlarmClock.EXTRA_MINUTES, min)
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                    }
                    "CALL" -> start(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$arg")))
                }
            } catch (_: Exception) { }
        }
        return reply.replace(tag, "").trim()
    }

    private fun start(c: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }

    private fun openApp(c: Context, name: String) {
        val pm = c.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().contains(name, ignoreCase = true)
        } ?: return
        pm.getLaunchIntentForPackage(match.activityInfo.packageName)?.let { start(c, it) }
    }
}
