package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var claudeEt: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "JARVIS"; textSize = 34f; gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Baslat'a bas, sonra \"Jarvis\" de."; gravity = Gravity.CENTER
        })

        claudeEt = EditText(this).apply {
            hint = "Claude API anahtari (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.claudeKey(this@MainActivity))
        }
        root.addView(claudeEt)

        root.addView(Button(this).apply {
            text = "Kaydet ve Baslat"
            setOnClickListener { startJarvis() }
        })
        root.addView(Button(this).apply {
            text = "Durdur"
            setOnClickListener {
                Prefs.setAuto(this@MainActivity, false)
                stopService(Intent(this@MainActivity, JarvisService::class.java))
                Toast.makeText(this@MainActivity, "Durduruldu", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Ustte gosterme izni (uygulama acmak icin)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        root.addView(Button(this).apply {
            text = "Pil kisitlamasini kaldir"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")))
            }
        })
        setContentView(root)
    }

    private fun startJarvis() {
        val ck = claudeEt.text.toString().trim()
        if (ck.isEmpty()) {
            Toast.makeText(this, "Claude API anahtarini gir", Toast.LENGTH_LONG).show(); return
        }
        Prefs.save(this, ck, "")

        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 1); return
        }
        launchService()
    }

    private fun launchService() {
        startForegroundService(Intent(this, JarvisService::class.java))
        Toast.makeText(this, "Jarvis calisiyor. \"Jarvis\" de!", Toast.LENGTH_LONG).show()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launchService()
        else Toast.makeText(this, "Mikrofon izni gerekli", Toast.LENGTH_LONG).show()
    }
}
