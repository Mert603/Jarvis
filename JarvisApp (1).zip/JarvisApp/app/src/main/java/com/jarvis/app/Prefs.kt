package com.jarvis.app

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun claudeKey(c: Context) = p(c).getString("claude", "") ?: ""
    fun picoKey(c: Context) = p(c).getString("pico", "") ?: ""
    fun autoStart(c: Context) = p(c).getBoolean("auto", false)
    fun save(c: Context, claude: String, pico: String) =
        p(c).edit().putString("claude", claude).putString("pico", pico).putBoolean("auto", true).apply()
    fun setAuto(c: Context, v: Boolean) = p(c).edit().putBoolean("auto", v).apply()
}
