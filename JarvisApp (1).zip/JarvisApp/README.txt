JARVIS - KURULUM
1) Android Studio (Koala veya yeni) kur: https://developer.android.com/studio
2) Zip'i ac, File > Open ile "JarvisApp" klasorunu sec. Gradle sync bitsin.
3) Ucretsiz Picovoice AccessKey al: https://console.picovoice.ai
4) Claude API anahtari al: https://console.anthropic.com
5) Telefonda USB hata ayiklamayi ac, bagla, Run ile yukle.
   APK dosyasi: Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk
6) Uygulamayi ac, iki anahtari yapistir, "Kaydet ve Baslat". Sonra "Jarvis" de.
7) Ayarlardan: "Ustte gosterme izni" ve "Pil kisitlamasi" butonlarini ac.

Ornek komutlar: "Jarvis, YouTube'u ac", "Jarvis, sabah 7.30'a alarm kur",
"Jarvis, Ankara'da bugun hava nasil" (internette arar), "Jarvis, bana fikra anlat".
