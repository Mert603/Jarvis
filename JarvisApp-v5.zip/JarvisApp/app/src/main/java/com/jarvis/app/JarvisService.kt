package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.Locale

class JarvisService : Service() {

    private enum class Mode { WAKE, COMMAND }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var busy = false
    private var mode = Mode.WAKE

    // "Jarvis" kelimesinin Turkce taniyicida yazilabilecek halleri
    private val wakeRegex = Regex("[jcçh]arv[iıî]s")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = NotificationCompat.Builder(this, "jarvis")
            .setContentTitle("Jarvis dinliyor")
            .setContentText("\"Jarvis\" de, cevap vereyim")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(1, n)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                ttsReady = true
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { resumeWake() }
            @Deprecated("deprecated") override fun onError(id: String?) { resumeWake() }
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        busy = false
        mode = Mode.WAKE
        startListening()
        return START_STICKY
    }

    private fun resumeWake() {
        main.post {
            busy = false
            mode = Mode.WAKE
            startListening()
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.trim().orEmpty()
            handle(text)
        }

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                speak("Mikrofon izni yok.")
                return
            }
            mode = Mode.WAKE
            restart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000L else 300L)
        }

        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handle(text: String) {
        if (mode == Mode.COMMAND) {
            if (text.isBlank()) { mode = Mode.WAKE; restart(300) } else ask(text)
            return
        }
        val lower = text.lowercase(Locale("tr", "TR"))
        val m = wakeRegex.find(lower)
        if (m == null) { restart(200); return }

        // "Jarvis YouTube'u ac" gibi tek cumlede komut geldiyse direkt calistir
        val cmd = lower.substring(m.range.last + 1).trim { !it.isLetterOrDigit() }
        if (cmd.length >= 3) {
            ask(cmd)
        } else {
            beep()
            mode = Mode.COMMAND
            restart(250)
        }
    }

    private fun beep() {
        try { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150) }
        catch (_: Exception) {}
    }

    private fun restart(delayMs: Long) {
        main.postDelayed({ startListening() }, delayMs)
    }

    private fun startListening() {
        main.post {
            if (busy) return@post
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                speak("Bu cihazda konusma tanima servisi yok.")
                return@post
            }
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
                r.setRecognitionListener(listener)
                r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                })
            }
        }
    }

    private fun ask(text: String) {
        busy = true
        recognizer?.destroy()
        recognizer = null
        val reply = try {
            Brain.handle(this, text)
        } catch (e: Exception) {
            Log.e("Jarvis", "Komut hatasi", e)
            "Bir sorun oldu."
        }
        speak(reply)
    }

    private fun speak(text: String) {
        busy = true
        if (!ttsReady) { main.postDelayed({ speak(text) }, 300); return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-utt")
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
