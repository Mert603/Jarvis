package com.jarvis.app

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun autoStart(c: Context) = p(c).getBoolean("auto", false)
    fun setAuto(c: Context, v: Boolean) = p(c).edit().putBoolean("auto", v).apply()
}
