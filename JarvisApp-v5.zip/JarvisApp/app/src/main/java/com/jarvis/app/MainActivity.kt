package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply { text = "JARVIS"; textSize = 34f; gravity = Gravity.CENTER })
        root.addView(TextView(this).apply {
            text = "Baslat'a bas, sonra \"Jarvis\" de. API anahtari gerekmez."
            gravity = Gravity.CENTER
        })
        root.addView(Button(this).apply { text = "Baslat"; setOnClickListener { startJarvis() } })
        root.addView(Button(this).apply {
            text = "Durdur"
            setOnClickListener {
                Prefs.setAuto(this@MainActivity, false)
                stopService(Intent(this@MainActivity, JarvisService::class.java))
                Toast.makeText(this@MainActivity, "Durduruldu", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Ustte gosterme izni (uygulama acmak icin)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(Button(this).apply {
            text = "Pil kisitlamasini kaldir"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        })
        root.addView(TextView(this).apply {
            text = "\nOrnek komutlar:\n" +
                "- Jarvis, saat kac\n- Jarvis, YouTube'u ac\n- Jarvis, yedi bucuga alarm kur\n" +
                "- Jarvis, bes dakika zamanlayici kur\n- Jarvis, internette kediler hakkinda ara\n" +
                "- Jarvis, YouTube'da Tarkan ara\n- Jarvis, feneri ac\n- Jarvis, sesi kis\n- Jarvis, fikra anlat"
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun startJarvis() {
        Prefs.setAuto(this, true)
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), 1); return }
        launchService()
    }

    private fun launchService() {
        startForegroundService(Intent(this, JarvisService::class.java))
        Toast.makeText(this, "Jarvis calisiyor. \"Jarvis\" de!", Toast.LENGTH_LONG).show()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launchService()
        else Toast.makeText(this, "Mikrofon izni gerekli", Toast.LENGTH_LONG).show()
    }
}
