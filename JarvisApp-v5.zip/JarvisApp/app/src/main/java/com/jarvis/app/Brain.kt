package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Yapay zeka kullanmadan, kurallarla Turkce komut anlayan beyin. */
object Brain {
    private val tr = Locale("tr", "TR")

    private val units = mapOf(
        "bir" to 1, "iki" to 2, "üç" to 3, "dört" to 4, "dörd" to 4, "beş" to 5,
        "altı" to 6, "yedi" to 7, "sekiz" to 8, "dokuz" to 9
    )
    private val tens = mapOf("on" to 10, "yirmi" to 20, "otuz" to 30, "kırk" to 40, "elli" to 50, "altmış" to 60)

    private val jokes = listOf(
        "Bilgisayar neden doktora gitti? Çünkü virüs kapmıştı.",
        "Temel ile Dursun uçakta. Temel demiş ki, yere bakınca insanlar karınca gibi görünüyor. Dursun demiş ki, onlar zaten karınca, daha inmedik.",
        "Programcı markete gidiyor. Eşi diyor ki, bir ekmek al, yumurta varsa altı tane al. Adam altı ekmekle dönüyor. Yumurta varmış çünkü.",
        "Adam doktora gitmiş, doktor bey unutkanlığım var demiş. Doktor, ne zamandır demiş. Adam, ne zamandır ne demiş."
    )

    private fun stem(tok: String): String {
        if (units.containsKey(tok) || tens.containsKey(tok)) return tok
        for (cut in 1..2) {
            if (tok.length > cut) {
                val s = tok.dropLast(cut)
                if (units.containsKey(s) || tens.containsKey(s)) return s
            }
        }
        return tok
    }

    /** tokens[i]'den baslayan sayiyi okur: (deger, kullanilan token sayisi) */
    private fun num(tokens: List<String>, i: Int): Pair<Int, Int>? {
        val tok = tokens[i]
        Regex("^(\\d+)").find(tok)?.let { return it.groupValues[1].toInt() to 1 }
        val base = stem(tok)
        val t = tens[base]
        if (t != null) {
            if (i + 1 < tokens.size) {
                val u = units[stem(tokens[i + 1])]
                if (u != null) return (t + u) to 2
            }
            return t to 1
        }
        units[base]?.let { return it to 1 }
        return null
    }

    private fun parseTime(t: String, tokens: List<String>): Pair<Int, Int>? {
        Regex("(\\d{1,2})\\s*[:.]\\s*(\\d{2})").find(t)?.let {
            val h = it.groupValues[1].toInt()
            val m = it.groupValues[2].toInt()
            if (h in 0..24 && m in 0..59) return h to m
        }
        for (i in tokens.indices) {
            val n = num(tokens, i) ?: continue
            if (n.first !in 0..24) continue
            if (tokens[i] == "bir" && tokens.getOrNull(i + 1)?.startsWith("alarm") == true) continue
            val j = i + n.second
            var m = 0
            if (j < tokens.size) {
                if (tokens[j].startsWith("buçuk")) m = 30
                else num(tokens, j)?.let { if (it.first in 0..59) m = it.first }
            }
            return n.first to m
        }
        return null
    }

    /** Sure ifadesini saniyeye cevirir: "5 dakika", "on saniye", "iki saat sonra" */
    private fun parseDuration(tokens: List<String>): Int? {
        if (tokens.contains("yarım") && tokens.any { it.startsWith("saat") }) return 1800
        for (i in tokens.indices) {
            val n = num(tokens, i) ?: continue
            val j = i + n.second
            val unit = tokens.getOrNull(j) ?: continue
            when {
                unit.startsWith("saniye") -> return n.first
                unit.startsWith("dakika") || unit == "dk" -> return n.first * 60
                unit.startsWith("saat") && (tokens.getOrNull(j + 1) in listOf("sonra", "için", null)) ->
                    return n.first * 3600
            }
        }
        return null
    }

    private fun norm(s: String) = s.lowercase(tr).filter { it.isLetterOrDigit() }

    private fun start(c: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }

    private fun web(c: Context, url: String) = start(c, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun openApp(c: Context, nameTokens: List<String>): String {
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).map {
            val label = it.loadLabel(pm).toString()
            Triple(norm(label), label, it.activityInfo.packageName)
        }
        var cand = norm(nameTokens.joinToString(""))
        var tries = 0
        while (cand.length >= 3 && tries <= 3) {
            val hit = apps.firstOrNull { it.first == cand }
                ?: apps.firstOrNull { it.first.startsWith(cand) }
                ?: apps.firstOrNull { it.first.contains(cand) }
            if (hit != null) {
                val li = pm.getLaunchIntentForPackage(hit.third) ?: break
                return try { start(c, li); "${hit.second} açılıyor." } catch (e: Exception) { "Uygulamayı açamadım." }
            }
            cand = cand.dropLast(1)
            tries++
        }
        return "${nameTokens.joinToString(" ")} uygulamasını bulamadım."
    }

    private fun torch(c: Context, on: Boolean): String = try {
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) "Bu cihazda fener yok."
        else { cm.setTorchMode(id, on); if (on) "Fener açıldı." else "Fener kapatıldı." }
    } catch (e: Exception) { "Feneri kullanamadım." }

    private fun volume(c: Context, dir: Int): String {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        repeat(if (dir == AudioManager.ADJUST_MUTE) 1 else 2) {
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        }
        return when (dir) {
            AudioManager.ADJUST_RAISE -> "Ses açıldı."
            AudioManager.ADJUST_LOWER -> "Ses kısıldı."
            else -> "Ses kapatıldı."
        }
    }

    /** Soyledigin cumleyi isler ve sesli okunacak cevabi dondurur. */
    fun handle(c: Context, raw: String): String {
        val t = raw.lowercase(tr).replace("’", "").replace("'", "")
        val tokens = t.replace(Regex("[^\\p{L}\\p{N}:. ]"), " ")
            .split(" ").map { it.trim('.', ':') }.filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return "Seni duyamadım."

        fun hasExact(vararg w: String) = tokens.any { it in w }
        fun startsAny(vararg p: String) = tokens.any { tok -> p.any { tok.startsWith(it) } }

        // Sohbet
        if (hasExact("merhaba", "selam", "selamlar")) return "Merhaba, nasıl yardımcı olabilirim?"
        if (hasExact("günaydın")) return "Günaydın! Bugün sana nasıl yardımcı olabilirim?"
        if (hasExact("nasılsın", "naber", "nabersin")) return "İyiyim, teşekkürler. Sen nasılsın?"
        if (startsAny("teşekkür", "sağol", "eyvallah")) return "Rica ederim."
        if (hasExact("adın", "ismin") || (hasExact("kimsin"))) return "Benim adım Jarvis."
        if (startsAny("fıkra", "şaka", "espri")) return jokes.random()
        if (hasExact("yardım") || (hasExact("neler") && startsAny("yapabil")))
            return "Uygulama açabilir, internette arama yapabilir, alarm ve zamanlayıcı kurabilir, saati söyleyebilir, feneri ve sesi ayarlayabilirim."

        // Saat / tarih
        if (hasExact("saat") && startsAny("kaç")) {
            val cal = Calendar.getInstance()
            val h = cal.get(Calendar.HOUR_OF_DAY)
            val m = cal.get(Calendar.MINUTE)
            return if (m == 0) "Saat $h." else "Saat $h $m."
        }
        if (startsAny("tarih", "günlerden") || hasExact("ayın")) {
            return "Bugün " + SimpleDateFormat("d MMMM yyyy EEEE", tr).format(Date()) + "."
        }

        // Fener
        if (startsAny("fener", "flaş", "flash")) {
            val off = hasExact("kapat", "kapa", "söndür")
            return torch(c, !off)
        }

        // Ses
        if (startsAny("sessiz")) return volume(c, AudioManager.ADJUST_MUTE)
        if (hasExact("ses", "sesi", "sesini")) {
            if (hasExact("kıs", "kısar", "azalt", "düşür")) return volume(c, AudioManager.ADJUST_LOWER)
            if (hasExact("aç", "artır", "arttır", "yükselt")) return volume(c, AudioManager.ADJUST_RAISE)
        }

        // Zamanlayici / alarm
        val dur = parseDuration(tokens)
        if (dur != null && (startsAny("alarm", "zamanlay", "sayaç", "hatırlat") || hasExact("kur"))) {
            return try {
                start(c, Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, dur)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                when {
                    dur % 3600 == 0 -> "${dur / 3600} saat için zamanlayıcı kuruldu."
                    dur >= 60 && dur % 60 == 0 -> "${dur / 60} dakika için zamanlayıcı kuruldu."
                    else -> "$dur saniye için zamanlayıcı kuruldu."
                }
            } catch (e: Exception) { "Zamanlayıcıyı kuramadım." }
        }
        if (startsAny("alarm")) {
            var (h, m) = parseTime(t, tokens) ?: return "Alarmı kaça kurayım? Örneğin, yedi buçuğa alarm kur de."
            if (h < 12 && (hasExact("akşam", "gece") || t.contains("öğleden sonra"))) h += 12
            if (h == 24) h = 0
            return try {
                start(c, Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h)
                    .putExtra(AlarmClock.EXTRA_MINUTES, m)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                "Alarm %02d:%02d için kuruldu.".format(h, m)
            } catch (e: Exception) { "Alarmı kuramadım." }
        }

        // Telefon numarasi arama
        val digits = t.filter { it.isDigit() }
        if (digits.length >= 7 && hasExact("ara", "arar")) {
            return try { start(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits"))); "Arama ekranı açılıyor." }
            catch (e: Exception) { "Arama yapamadım." }
        }

        val searchVerbs = setOf("ara", "arat", "araştır", "bul")
        val playVerbs = setOf("çal", "dinle", "dinlet", "oynat", "izle")

        // YouTube'da arama veya sarki
        val yt = startsAny("youtube", "yutup", "yotub")
        val musicWord = startsAny("şarkı", "müzik", "klip")
        if ((yt && hasExact(*searchVerbs.toTypedArray(), *playVerbs.toTypedArray())) ||
            (hasExact(*playVerbs.toTypedArray()) || (musicWord && hasExact("aç")))) {
            val stop = searchVerbs + playVerbs + setOf("aç", "da", "de", "ta", "te", "şarkısını", "şarkısı", "şarkı", "müziği", "müzik", "klibini", "klip")
            val q = tokens.filterNot { it in stop || it.startsWith("youtube") || it.startsWith("yutup") }
                .joinToString(" ").ifBlank { "müzik" }
            return try { web(c, "https://www.youtube.com/results?search_query=${enc(q)}"); "YouTube'da $q açılıyor." }
            catch (e: Exception) { "Açamadım." }
        }

        // Internette arama
        if (hasExact(*searchVerbs.toTypedArray()) || startsAny("hava")) {
            val q = if (startsAny("hava")) "hava durumu" else
                tokens.filterNot { it in searchVerbs || it.startsWith("google") || it.startsWith("internet") || it == "da" || it == "de" }
                    .joinToString(" ")
            if (q.isBlank()) return "Neyi aramamı istersin?"
            return try { web(c, "https://www.google.com/search?q=${enc(q)}"); "$q için arıyorum." }
            catch (e: Exception) { "Arama yapamadım." }
        }

        // Uygulama acma
        if (hasExact("aç", "açar", "başlat", "çalıştır", "git", "gir")) {
            val skip = setOf("aç", "açar", "başlat", "çalıştır", "git", "gir", "uygulamasını", "uygulaması",
                "uygulamayı", "uygulama", "programı", "programını", "lütfen", "bana", "şunu", "bunu")
            val name = tokens.filterNot { it in skip }
            if (name.isEmpty()) return "Hangi uygulamayı açayım?"
            return openApp(c, name)
        }

        return "Bunu anlayamadım. Uygulama aç, internette ara, alarm kur ya da saat kaç gibi komutlar söyleyebilirsin."
    }
}
